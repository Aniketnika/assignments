from django.db import models

# Create your models here.
class User(models.Model):
    Prodid = models.CharField(max_length=7)
    Prodname = models.CharField(max_length=50)
    Prodtype1 = models.CharField(max_length=25)
    Price = models.CharField(max_length=8)
    Prodtype2 = models.CharField(max_length=25)
