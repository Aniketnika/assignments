from django.db import models

# Create your models here.
class User(models.Model):
    Prodid = models.IntegerField(max_length=7,primary_key=True)
    Prodname = models.CharField(max_length=50)
    Prodtype1 = models.CharField(max_length=25)
    Price = models.FloatField(max_length=8)
    Prodtype2 = models.CharField(max_length=25)
